﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceService.Model
{
    public class IndustryIdentifier
    {
        public string type { get; set; }
        public string identifier { get; set; }
    }
}
