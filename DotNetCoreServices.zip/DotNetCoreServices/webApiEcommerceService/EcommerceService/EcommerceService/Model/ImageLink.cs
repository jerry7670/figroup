﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceService.Model
{
    public class ImageLink
    {
        public string smallThumbnail { get; set; }
        public string thumbnail { get; set; }
    }
}
