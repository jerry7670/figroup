﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Newtonsoft.Json;
using EcommerceService.Model;
using Microsoft.AspNetCore.Cors;
using EcommerceService.app_Code;

namespace EcommerceService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        [EnableCors("MyPolicy")]
        public ActionResult<BookModel> Get()
        {
            return DataAccess.GetAllData();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        [EnableCors("MyPolicy")]
        public Item Get(string id)
        {
            return DataAccess.GetDataById(id);
        }
    }
}
