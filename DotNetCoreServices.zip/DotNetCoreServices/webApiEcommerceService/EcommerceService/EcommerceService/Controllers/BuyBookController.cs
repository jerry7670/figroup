﻿using Newtonsoft.Json;
using EcommerceService.Model;
using Microsoft.AspNetCore.Cors;
using EcommerceService.app_Code;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace EcommerceService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BuyBookController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        [EnableCors("MyPolicy")]
        public List<Object> Get()
        {
            Motorbike motorbike = new Motorbike();
            Train train = new Train();
            Aircraft aricraft = new Aircraft();
            var costs = new List<Object>();
            costs.Add(motorbike);
            costs.Add(train);
            costs.Add(aricraft);

            return costs;
        }

        [HttpPost]
        [EnableCors("MyPolicy")]
        public string BuyBook([FromBody] BuyBookModel model)
        {
            string driverName = "Jerry";
            string mobilephone = "021686807";
            DateTime deliveryDate = DateTime.Now.AddDays(2);
            if (model.DeliveryService.Equals(""))
            { }


            var info = DeliveryInfroGenerator.Process(driverName, mobilephone, deliveryDate);

            return info;
        }
    }
}