﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using EcommerceService.Model;
using Microsoft.AspNetCore.Cors;

namespace EcommerceService.app_Code
{
    public class DataAccess
    {
        public static ActionResult<BookModel>  GetAllData()
        {
            var webClient = new WebClient();
            var json = webClient.DownloadString(@"https://www.googleapis.com/books/v1/volumes?q=%7bsearch");
            var data = JsonConvert.DeserializeObject<BookModel>(json);

            return data;
        }

        internal static Item GetDataById(string id)
        {
            var webClient = new WebClient();
            var json = webClient.DownloadString(@"https://www.googleapis.com/books/v1/volumes?q=%7bsearch");
            var data = JsonConvert.DeserializeObject<BookModel>(json).items.Where(i => i.id == id).FirstOrDefault();

            return data;
        }
    }
}
