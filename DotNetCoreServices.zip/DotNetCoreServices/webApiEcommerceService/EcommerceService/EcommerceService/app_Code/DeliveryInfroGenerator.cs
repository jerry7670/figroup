﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceService.app_Code
{
    public class DeliveryInfroGenerator
    {
        public static string Process(string driverName,
                                     string mobilephone,
                                     DateTime deliveryDate)
        {
            return driverName+" ("+mobilephone+") will deliver on "+ deliveryDate.ToString("yyyy/MMM/dd");
        }
    }
}
