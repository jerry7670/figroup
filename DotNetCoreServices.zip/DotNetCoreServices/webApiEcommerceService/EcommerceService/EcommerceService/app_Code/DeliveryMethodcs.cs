﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceService.app_Code
{
    public class DeliveryMethodcs
    {
              
        public string arrival { get; set; }
        public double baseCost { get; set; }
        public double factorJuneAug { get; set; }
        public double factorSep { get; set; }
        public double factorOtherMonths { get; set; }
        public double totalCost { get; set; }
        public string name { get; set; }
        public double CalculateCost()
        {
            
            double factor = factorOtherMonths;
            int month = DateTime.Now.Month;
            if(month>=6 && month <=8)
            {
                factor = factorJuneAug;
            }
            else if(month==9)
            { factor = factorSep; }
            double totalCost = baseCost+ factor;
            return totalCost;
        }
    }

    public class Motorbike: DeliveryMethodcs
    {
        public Motorbike()
        {
            name = "Motorbike";
            baseCost = 5;
            factorJuneAug =0.5;
            factorSep = 1.5;
            factorOtherMonths = 1;
            totalCost = CalculateCost();
            arrival = DateTime.Now.AddDays(5).ToString("yyyy/MMM/dd");
        }
        public string driverName { get; set; }
        public string mobile { get; set; }
    }

    public class Train : DeliveryMethodcs
    {
        public Train()
        {
            name = "Train";
            baseCost = 10;
            factorJuneAug = 0.8;
            factorSep = 1.8;
            factorOtherMonths = 1;
            totalCost = CalculateCost();
            arrival = DateTime.Now.AddDays(3).ToString("yyyy/MMM/dd");
        }
        public string trainNo { get; set; }
        public string stationOfArrival { get; set; }
    }

    public class Aircraft : DeliveryMethodcs
    {
        public Aircraft()
        {
            name = "Aircraft";
            baseCost = 20;
            factorJuneAug = 0.8;
            factorSep = 2;
            factorOtherMonths = 1;
            totalCost = CalculateCost();
            arrival = DateTime.Now.AddDays(1).ToString("yyyy/MMM/dd");
        }
        public string flightNo { get; set; }
        public string gateOfArrival { get; set; }
    }
}
