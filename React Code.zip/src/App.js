import React, { Component } from "react";
import { Route, Redirect, Switch } from "react-router-dom";
import Books from "./components/books";
import BookDetail from "./components/bookDetail";
import NotFound from "./components/notFound";
import Confirmation from "./components/confirmation";
import NavBar from "./components/navBar";
import "./App.css";

class App extends Component {
  render() {
    return (
      <React.Fragment>
        <NavBar />
        <main className="container">
          <Switch>
            <Route path="/books/:id" component={BookDetail} />
            <Route path="/books" component={Books} />
            <Route path="/not-found" component={NotFound} />
            <Route path="/confirmation" component={Confirmation} />
            <Redirect from="/" exact to="/books" />
            <Redirect to="/not-found" />
          </Switch>
        </main>
      </React.Fragment>
    );
  }
}

export default App;
