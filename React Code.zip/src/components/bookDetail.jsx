import React from "react";
import Form from "./common/form";
import "../cssStyle/myStyles.css";
import {
  getBook,
  getDeliveryRate,
  postDeliveryRate
} from "../services/bookService";

class BookDetail extends Form {
  state = {
    book: {},
    delivery: {},
    type: "",
    currentCost: 0,
    currentDelivery: {}
  };

  async componentDidMount() {
    const bookId = this.props.match.params.id;

    const { data: book } = await getBook(bookId);
    const { data: delivery } = await getDeliveryRate();
    if (!book) return this.props.history.replace("/not-found");

    this.setState({ book, delivery });
  }

  handleDeliveryMethod = delivery => {
    
    this.setState({
      type: delivery && delivery.name,
      currentCost: delivery && delivery.totalCost,
      currentDelivery: delivery 
    });
  };

  handleBuy = async () => {
    //buyBook(this.state.data);
    //console.log("info", this.state.currentDelivery);
    const { data: info } = await postDeliveryRate(this.state.currentDelivery);
    console.log("info", info);
    //this.props.history.push("/confirmation",info);
    this.props.history.push("/confirmation", { info: info });
  };

  render() {
    //console.log("title", this.state.book.volumeInfo);
    const { volumeInfo } = this.state.book;
    const { delivery } = this.state;
    return (
      <React.Fragment>
        <table>
          <tbody>
            <tr>
              <td>
                <img
                  src={volumeInfo && volumeInfo.imageLinks.thumbnail}
                  alt="thumbnail"
                />
              </td>
              <td>
                <h2>{volumeInfo && volumeInfo.subtitle}</h2>
              </td>
            </tr>
          </tbody>
        </table>
        <h1>{volumeInfo && volumeInfo.title}</h1>
        <h2>
          {volumeInfo &&
            volumeInfo.authors + " - (" + volumeInfo.publishedDate + ")"}
        </h2>
        <p>
          Ship via - {this.state.type} ${this.state.currentCost}
        </p>
        <hr />
        <table>
          <tbody>
            <tr>
              <td>
                {" "}
                <button
                  className="MotobikeButton"
                  onClick={() => this.handleDeliveryMethod(delivery[0])}
                >
                  MOTOBIKE ${delivery[0] && delivery[0].totalCost}
                </button>
              </td>
              <td>
                <button
                  className="TrainButton"
                  onClick={() => this.handleDeliveryMethod(delivery[1])}
                >
                  TRAIN ${delivery[1] && delivery[1].totalCost}
                </button>
              </td>
              <td>
                {" "}
                <button
                  className="AircrateButton"
                  onClick={() => this.handleDeliveryMethod(delivery[2])}
                >
                  AIRCRAFT ${delivery[2] && delivery[2].totalCost}
                </button>
              </td>
            </tr>
          </tbody>
        </table>

        <button className="BuyButton" onClick={() => this.handleBuy()}>
          Buy
        </button>
      </React.Fragment>
    );
  }
}

export default BookDetail;
