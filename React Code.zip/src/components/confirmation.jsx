import React from "react";

const Confirmation = info => {

  return <h1>{info.location.state.info} Order Complete</h1>;
};

export default Confirmation;
