import React, { Component } from "react";
import { Link } from "react-router-dom";
import Table from "./common/table";


class BooksTable extends Component {
  columns = [
    { path: "Image", label: "Image",content:book=>(<img src={book.volumeInfo.imageLinks.smallThumbnail} alt="thumbnail" />) },
    {
      path: "title",
      label: "Title",
      content: book => (
        <Link to={`/books/${book.id}`}>{book.volumeInfo.title}</Link>
      )
    },
    { path: "Author", label: "Author", content:book=>(<p>{book.volumeInfo.authors}</p>) },
    { path: "Published", label: "Published date", content:book=>(<p>{book.volumeInfo.publishedDate}</p>)},
  ];

  render() {
    const { books, onSort, sortColumn } = this.props;
    console.log("book table stage", books);
    return (
      <Table
        columns={this.columns}
        data={books}
        sortColumn={sortColumn}
        onSort={onSort}
      />
    );
  }
}

export default BooksTable;
