import http from "./httpService";
import { bookApiUrl,deliveryApiUrl } from "../config.json";

const bookApiEndpoint = bookApiUrl;
const deliveryApiEndpoint = deliveryApiUrl;

function bookUrl(id) {

  return `${bookApiEndpoint}/${id}`;
}

export function getBooks() {
  return http.get(bookApiEndpoint);
}

export function getBook(bookId) {
  return http.get(bookUrl(bookId));
}

export function getDeliveryRate() {
  return http.get(deliveryApiEndpoint);
}

export function postDeliveryRate(delivery) {
  return http.post(deliveryApiEndpoint,delivery);
}

